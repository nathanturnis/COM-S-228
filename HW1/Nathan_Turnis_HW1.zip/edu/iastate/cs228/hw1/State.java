package edu.iastate.cs228.hw1;

/**
 * @author Nathan Turnis
 */

/**
 * 
 * Different forms of life. 
 *
 */
public enum State 
{
	BADGER, EMPTY, FOX, GRASS, RABBIT 
}

