package edu.iastate.cs228.hw1;

/**
 *  
 * @author Nathan Turnis
 *
 */

/**
 * 
 * To be implemented by the Animal class. 
 *
 */
public interface MyAge 
{
	int myAge();	// return age of the animal
}
